nuget restore Parser/Parser.sln
