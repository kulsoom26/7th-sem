﻿namespace Parser
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTime = new System.Windows.Forms.Label();
            this.ll_1_Tab = new System.Windows.Forms.TabPage();
            this.dataGridViewLL_1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewReport = new System.Windows.Forms.DataGridView();
            this.Result = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InputText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Stack = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPreprocess = new System.Windows.Forms.TabPage();
            this.listBoxFirst = new System.Windows.Forms.ListBox();
            this.listBoxFollow = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtgrammarFile = new System.Windows.Forms.TextBox();
            this.btnChooseFile = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTestFile = new System.Windows.Forms.TextBox();
            this.btnChooseTestFile = new System.Windows.Forms.Button();
            this.listBoxGrammar = new System.Windows.Forms.ListBox();
            this.tabItem = new System.Windows.Forms.TabControl();
            this.ll_1_Tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLL_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReport)).BeginInit();
            this.tabPreprocess.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabItem.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTime
            // 
            this.lblTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTime.AutoSize = true;
            this.lblTime.BackColor = System.Drawing.Color.Transparent;
            this.lblTime.ForeColor = System.Drawing.SystemColors.Window;
            this.lblTime.Location = new System.Drawing.Point(20, 729);
            this.lblTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(51, 20);
            this.lblTime.TabIndex = 4;
            this.lblTime.Text = "label4";
            // 
            // ll_1_Tab
            // 
            this.ll_1_Tab.Controls.Add(this.dataGridViewReport);
            this.ll_1_Tab.Controls.Add(this.dataGridViewLL_1);
            this.ll_1_Tab.Location = new System.Drawing.Point(4, 29);
            this.ll_1_Tab.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ll_1_Tab.Name = "ll_1_Tab";
            this.ll_1_Tab.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ll_1_Tab.Size = new System.Drawing.Size(964, 676);
            this.ll_1_Tab.TabIndex = 2;
            this.ll_1_Tab.Text = "LL(1)";
            this.ll_1_Tab.UseVisualStyleBackColor = true;
            this.ll_1_Tab.Enter += new System.EventHandler(this.ll_1_Tab_Enter);
            // 
            // dataGridViewLL_1
            // 
            this.dataGridViewLL_1.AllowUserToAddRows = false;
            this.dataGridViewLL_1.AllowUserToDeleteRows = false;
            this.dataGridViewLL_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewLL_1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewLL_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLL_1.Location = new System.Drawing.Point(9, 9);
            this.dataGridViewLL_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewLL_1.Name = "dataGridViewLL_1";
            this.dataGridViewLL_1.ReadOnly = true;
            this.dataGridViewLL_1.RowHeadersWidth = 62;
            this.dataGridViewLL_1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridViewLL_1.Size = new System.Drawing.Size(942, 262);
            this.dataGridViewLL_1.TabIndex = 1;
            // 
            // dataGridViewReport
            // 
            this.dataGridViewReport.AllowUserToAddRows = false;
            this.dataGridViewReport.AllowUserToDeleteRows = false;
            this.dataGridViewReport.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Stack,
            this.InputText,
            this.Result});
            this.dataGridViewReport.Location = new System.Drawing.Point(9, 280);
            this.dataGridViewReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewReport.Name = "dataGridViewReport";
            this.dataGridViewReport.ReadOnly = true;
            this.dataGridViewReport.RowHeadersWidth = 62;
            this.dataGridViewReport.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridViewReport.Size = new System.Drawing.Size(942, 329);
            this.dataGridViewReport.TabIndex = 2;
            // 
            // Result
            // 
            this.Result.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Result.HeaderText = "Result";
            this.Result.MinimumWidth = 8;
            this.Result.Name = "Result";
            this.Result.ReadOnly = true;
            // 
            // InputText
            // 
            this.InputText.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.InputText.HeaderText = "InputText";
            this.InputText.MinimumWidth = 8;
            this.InputText.Name = "InputText";
            this.InputText.ReadOnly = true;
            // 
            // Stack
            // 
            this.Stack.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Stack.HeaderText = "Stack";
            this.Stack.MinimumWidth = 8;
            this.Stack.Name = "Stack";
            this.Stack.ReadOnly = true;
            // 
            // tabPreprocess
            // 
            this.tabPreprocess.Controls.Add(this.label3);
            this.tabPreprocess.Controls.Add(this.label2);
            this.tabPreprocess.Controls.Add(this.listBoxFollow);
            this.tabPreprocess.Controls.Add(this.listBoxFirst);
            this.tabPreprocess.Location = new System.Drawing.Point(4, 29);
            this.tabPreprocess.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPreprocess.Name = "tabPreprocess";
            this.tabPreprocess.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPreprocess.Size = new System.Drawing.Size(964, 676);
            this.tabPreprocess.TabIndex = 1;
            this.tabPreprocess.Text = "Preprocessing";
            this.tabPreprocess.UseVisualStyleBackColor = true;
            this.tabPreprocess.Enter += new System.EventHandler(this.TabPreprocess_Enter);
            // 
            // listBoxFirst
            // 
            this.listBoxFirst.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxFirst.FormattingEnabled = true;
            this.listBoxFirst.ItemHeight = 20;
            this.listBoxFirst.Location = new System.Drawing.Point(9, 98);
            this.listBoxFirst.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listBoxFirst.Name = "listBoxFirst";
            this.listBoxFirst.Size = new System.Drawing.Size(470, 424);
            this.listBoxFirst.TabIndex = 3;
            // 
            // listBoxFollow
            // 
            this.listBoxFollow.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxFollow.FormattingEnabled = true;
            this.listBoxFollow.ItemHeight = 20;
            this.listBoxFollow.Location = new System.Drawing.Point(490, 100);
            this.listBoxFollow.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listBoxFollow.Name = "listBoxFollow";
            this.listBoxFollow.Size = new System.Drawing.Size(458, 424);
            this.listBoxFollow.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(105, 77);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "First Sets";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(669, 75);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Follow Sets";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.listBoxGrammar);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Size = new System.Drawing.Size(964, 676);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Scanning Phase";
            this.tabPage1.Leave += new System.EventHandler(this.tabPage1_Leave);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.btnChooseTestFile);
            this.groupBox1.Controls.Add(this.txtTestFile);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnChooseFile);
            this.groupBox1.Controls.Add(this.txtgrammarFile);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(9, 9);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(942, 120);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose File";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(22, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Grammar File Path:";
            // 
            // txtgrammarFile
            // 
            this.txtgrammarFile.BackColor = System.Drawing.SystemColors.Window;
            this.txtgrammarFile.Enabled = false;
            this.txtgrammarFile.Location = new System.Drawing.Point(176, 32);
            this.txtgrammarFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtgrammarFile.Name = "txtgrammarFile";
            this.txtgrammarFile.Size = new System.Drawing.Size(620, 26);
            this.txtgrammarFile.TabIndex = 1;
            // 
            // btnChooseFile
            // 
            this.btnChooseFile.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnChooseFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChooseFile.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnChooseFile.Location = new System.Drawing.Point(825, 28);
            this.btnChooseFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnChooseFile.Name = "btnChooseFile";
            this.btnChooseFile.Size = new System.Drawing.Size(98, 35);
            this.btnChooseFile.TabIndex = 2;
            this.btnChooseFile.Text = "Browse";
            this.btnChooseFile.UseVisualStyleBackColor = false;
            this.btnChooseFile.Click += new System.EventHandler(this.btnChooseFile_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(54, 80);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Test File Path:";
            // 
            // txtTestFile
            // 
            this.txtTestFile.Enabled = false;
            this.txtTestFile.Location = new System.Drawing.Point(176, 75);
            this.txtTestFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTestFile.Name = "txtTestFile";
            this.txtTestFile.Size = new System.Drawing.Size(620, 26);
            this.txtTestFile.TabIndex = 4;
            // 
            // btnChooseTestFile
            // 
            this.btnChooseTestFile.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnChooseTestFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChooseTestFile.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnChooseTestFile.Location = new System.Drawing.Point(825, 72);
            this.btnChooseTestFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnChooseTestFile.Name = "btnChooseTestFile";
            this.btnChooseTestFile.Size = new System.Drawing.Size(98, 35);
            this.btnChooseTestFile.TabIndex = 5;
            this.btnChooseTestFile.Text = "Browse";
            this.btnChooseTestFile.UseVisualStyleBackColor = false;
            this.btnChooseTestFile.Click += new System.EventHandler(this.btnChooseTestFile_Click);
            // 
            // listBoxGrammar
            // 
            this.listBoxGrammar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxGrammar.BackColor = System.Drawing.Color.White;
            this.listBoxGrammar.FormattingEnabled = true;
            this.listBoxGrammar.ItemHeight = 20;
            this.listBoxGrammar.Location = new System.Drawing.Point(9, 138);
            this.listBoxGrammar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listBoxGrammar.Name = "listBoxGrammar";
            this.listBoxGrammar.Size = new System.Drawing.Size(940, 504);
            this.listBoxGrammar.TabIndex = 2;
            // 
            // tabItem
            // 
            this.tabItem.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabItem.Controls.Add(this.tabPage1);
            this.tabItem.Controls.Add(this.tabPreprocess);
            this.tabItem.Controls.Add(this.ll_1_Tab);
            this.tabItem.Location = new System.Drawing.Point(18, 15);
            this.tabItem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabItem.Name = "tabItem";
            this.tabItem.SelectedIndex = 0;
            this.tabItem.Size = new System.Drawing.Size(972, 709);
            this.tabItem.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabItem.TabIndex = 3;
            this.tabItem.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabItem_Selecting);
            this.tabItem.Enter += new System.EventHandler(this.tabItem_Enter);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BackgroundImage = global::Parser.Properties.Resources.blue_wavy_abstract_background_1409_897;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1008, 763);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.tabItem);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configure";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.ll_1_Tab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLL_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReport)).EndInit();
            this.tabPreprocess.ResumeLayout(false);
            this.tabPreprocess.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabItem.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.TabPage ll_1_Tab;
        private System.Windows.Forms.DataGridView dataGridViewReport;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stack;
        private System.Windows.Forms.DataGridViewTextBoxColumn InputText;
        private System.Windows.Forms.DataGridViewTextBoxColumn Result;
        private System.Windows.Forms.DataGridView dataGridViewLL_1;
        private System.Windows.Forms.TabPage tabPreprocess;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBoxFollow;
        private System.Windows.Forms.ListBox listBoxFirst;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListBox listBoxGrammar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnChooseTestFile;
        private System.Windows.Forms.TextBox txtTestFile;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnChooseFile;
        private System.Windows.Forms.TextBox txtgrammarFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabItem;
    }
}

