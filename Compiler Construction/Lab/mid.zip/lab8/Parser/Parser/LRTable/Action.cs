﻿namespace Parser.State
{
    /// <summary>
    /// 
    /// </summary>
    public enum Action
    {
        Reduce = 0,
        Shift = 1,
        Accept = 2,
    }
}