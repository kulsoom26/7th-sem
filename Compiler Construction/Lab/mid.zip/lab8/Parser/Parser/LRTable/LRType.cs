﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parser.LLTable
{
    public enum LRType
    {
        Zero=0,
        SLR_One=1,
        ClR_One=2
    }
}
