﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parser.Models
{
    public class ParseReportModel
    {
        public string Stack { get; set; }
        public string InputString { get; set; }
        public string Output { get; set; }
    }
}
