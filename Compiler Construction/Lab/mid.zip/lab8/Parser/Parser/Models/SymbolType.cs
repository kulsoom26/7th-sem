﻿namespace Parser.Models
{
    public enum SymbolType
    {
        Terminal =0,
        Variable = 1,
    }
}